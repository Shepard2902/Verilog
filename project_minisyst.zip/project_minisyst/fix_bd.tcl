# =============================================================================
# fix_bd.tcl
# Run in Vivado TCL Console to patch minisyst_bd
# Type in TCL console: source C:/path/to/fix_bd.tcl
# =============================================================================

# Make sure we are working on the right BD
current_bd_design minisyst_bd

# -----------------------------------------------------------------------------
# FIX 1 — Connect missing axi_cmd_valid <-> cmd_valid
# -----------------------------------------------------------------------------
connect_bd_net [get_bd_pins mem_ctrl_0/axi_cmd_valid] \
               [get_bd_pins axi4_lite_master_0/cmd_valid]

# -----------------------------------------------------------------------------
# FIX 2 — seq_core rst: drive it from OR(peripheral_reset, risc_reset)
# Add a Utility Vector Logic cell configured as 2-input OR
# This satisfies Vivado's clock-domain checker AND keeps MemCtrl control
# -----------------------------------------------------------------------------
startgroup
create_bd_cell -type ip -vlnv xilinx.com:ip:util_vector_logic:2.0 or_reset
endgroup

# Configure as 2-input OR, 1-bit wide
set_property -dict [list \
    CONFIG.C_SIZE {1} \
    CONFIG.C_OPERATION {or} \
] [get_bd_cells or_reset]

# Disconnect the direct risc_reset -> seq_core/rst wire
delete_bd_objs [get_bd_nets mem_ctrl_0_risc_reset]

# Connect inputs: Op1 = peripheral_reset (board reset, active-high)
#                 Op2 = risc_reset       (MemCtrl reset command)
connect_bd_net [get_bd_pins proc_sys_reset_0/peripheral_reset] \
               [get_bd_pins or_reset/Op1]
connect_bd_net [get_bd_pins mem_ctrl_0/risc_reset] \
               [get_bd_pins or_reset/Op2]

# Connect OR output to seq_core rst
connect_bd_net [get_bd_pins or_reset/Res] \
               [get_bd_pins seq_core_0/rst]

# -----------------------------------------------------------------------------
# FIX 3 — Configure blk_mem_gen_0 correctly (16-bit wide, 1024 deep, ROM)
# The default is 32-bit wide which mismatches seq_core instruction[15:0]
# -----------------------------------------------------------------------------
set_property -dict [list \
    CONFIG.Memory_Type        {Single_Port_ROM} \
    CONFIG.Width_A            {16} \
    CONFIG.Depth_A            {1024} \
    CONFIG.Read_Width_A       {16} \
    CONFIG.Write_Width_A      {16} \
    CONFIG.Write_Depth_A      {1024} \
    CONFIG.Read_Depth_A       {1024} \
    CONFIG.EN_SAFETY_CKT      {false} \
    CONFIG.Load_Init_File     {true} \
    CONFIG.Coe_File           {C:/Users/flore/Desktop/DSD/project_minisyst/program.coe} \
] [get_bd_cells blk_mem_gen_0]

# -----------------------------------------------------------------------------
# Validate and save
# -----------------------------------------------------------------------------
validate_bd_design
save_bd_design

puts "=========================================================="
puts " All fixes applied. Check messages above for any errors."
puts "=========================================================="
