`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05/19/2026 01:27:46 PM
// Design Name: 
// Module Name: top_minisystem
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// =============================================================================
// top_minisystem.v
// Top-level integration:
//
//   host PC (USB/UART) <--> USB-UART adapter <--> [FPGA]
//                                                     |-- Xilinx AXI Uartlite IP
//                                                     |-- axi4_lite_master
//                                                     |-- mem_ctrl (FSM)
//                                                     |-- block_memory (BRAM)
//                                                     |-- RISC core (pre-existing)
//
// Pin assignments (constraint file not included here):
//   clk      -> board clock (e.g. 100 MHz)
//   rst_btn  -> active-low push-button reset
//   uart_rx  -> FPGA RX pin (from USB-UART adapter TX)
//   uart_tx  -> FPGA TX pin (to USB-UART adapter RX)
// =============================================================================

// =============================================================================
// top_minisystem.v
// Top-level integration:
//
//   host PC (USB/UART) <--> USB-UART adapter <--> [FPGA]
//                                                     |-- Xilinx AXI Uartlite IP
//                                                     |-- axi4_lite_master
//                                                     |-- mem_ctrl (FSM)
//                                                     |-- block_memory (BRAM)
//                                                     |-- RISC core (pre-existing)
//
// Pin assignments (constraint file not included here):
//   clk      -> board clock (e.g. 100 MHz)
//   rst_btn  -> active-low push-button reset
//   uart_rx  -> FPGA RX pin (from USB-UART adapter TX)
//   uart_tx  -> FPGA TX pin (to USB-UART adapter RX)
// =============================================================================

module top_minisystem #(
    parameter MEM_DEPTH  = 1024,       // 32-bit words  (= 4 KB)
    parameter UART_BASE  = 32'h4060_0000
)(
    input  wire clk,
    input  wire rst_btn,    // active-low external reset button

    // UART physical pins (wired inside AXI Uartlite IP)
    input  wire uart_rx,
    output wire uart_tx,

    // Instruction memory interface (connect to program ROM in block design)
    output wire [9:0]  imem_addr,    // PC output  -> ROM address (10-bit for 1K words)
    input  wire [15:0] imem_data     // ROM output -> instruction word
);

    // =========================================================================
    // 1.  Reset synchroniser (2-FF, active-high internal reset)
    // =========================================================================
    reg [1:0] rst_sync;
    wire      rst_n = rst_sync[1];

    always @(posedge clk or negedge rst_btn) begin
        if (!rst_btn) rst_sync <= 2'b00;
        else          rst_sync <= {rst_sync[0], 1'b1};
    end

    // =========================================================================
    // 2.  AXI4-Lite bus signals (MemCtrl master <-> UART slave)
    // =========================================================================
    wire [31:0] m_axi_awaddr;
    wire        m_axi_awvalid, m_axi_awready;
    wire [31:0] m_axi_wdata;
    wire  [3:0] m_axi_wstrb;
    wire        m_axi_wvalid,  m_axi_wready;
    wire  [1:0] m_axi_bresp;
    wire        m_axi_bvalid,  m_axi_bready;
    wire [31:0] m_axi_araddr;
    wire        m_axi_arvalid, m_axi_arready;
    wire [31:0] m_axi_rdata;
    wire  [1:0] m_axi_rresp;
    wire        m_axi_rvalid,  m_axi_rready;

    // =========================================================================
    // 3.  AXI4-Lite master command/response wires
    // =========================================================================
    wire        axi_cmd_valid, axi_cmd_ready;
    wire        axi_cmd_wr;
    wire [31:0] axi_cmd_addr, axi_cmd_wdata;
    wire        axi_rsp_valid;
    wire [31:0] axi_rsp_rdata;

    // =========================================================================
    // 4.  BRAM interface wires (Port B = MemCtrl side)
    // =========================================================================
    localparam ADDR_W = $clog2(MEM_DEPTH);

    wire               mem_en_b;
    wire  [3:0]        mem_we_b;
    wire [ADDR_W-1:0]  mem_addr_b;
    wire  [31:0]       mem_din_b;
    wire  [31:0]       mem_dout_b;

    // =========================================================================
    // 5.  RISC core control wires
    // =========================================================================
    wire risc_reset, risc_stop, risc_start;

    // RISC core port-A BRAM wires (driven by RISC core)
    wire               mem_en_a;
    wire  [3:0]        mem_we_a;
    wire [ADDR_W-1:0]  mem_addr_a;
    wire  [31:0]       mem_din_a;
    wire  [31:0]       mem_dout_a;

    // =========================================================================
    // 6.  AXI Uartlite LogiCORE IP instantiation
    //     (generated by Vivado IP Catalog; name may differ in your project)
    // =========================================================================
    axi_uartlite_0 u_uart (
        // Clocking & reset
        .s_axi_aclk    (clk),
        .s_axi_aresetn (rst_n),
        // Write address channel
        .s_axi_awaddr  (m_axi_awaddr[3:0]),  // Uartlite uses 4-bit addr
        .s_axi_awvalid (m_axi_awvalid),
        .s_axi_awready (m_axi_awready),
        // Write data channel
        .s_axi_wdata   (m_axi_wdata),
        .s_axi_wstrb   (m_axi_wstrb),
        .s_axi_wvalid  (m_axi_wvalid),
        .s_axi_wready  (m_axi_wready),
        // Write response channel
        .s_axi_bresp   (m_axi_bresp),
        .s_axi_bvalid  (m_axi_bvalid),
        .s_axi_bready  (m_axi_bready),
        // Read address channel
        .s_axi_araddr  (m_axi_araddr[3:0]),
        .s_axi_arvalid (m_axi_arvalid),
        .s_axi_arready (m_axi_arready),
        // Read data channel
        .s_axi_rdata   (m_axi_rdata),
        .s_axi_rresp   (m_axi_rresp),
        .s_axi_rvalid  (m_axi_rvalid),
        .s_axi_rready  (m_axi_rready),
        // UART physical pins
        .rx            (uart_rx),
        .tx            (uart_tx),
        // Interrupt (not used)
        .interrupt     ()
    );

    // =========================================================================
    // 7.  AXI4-Lite master
    // =========================================================================
    axi4_lite_master u_axi_master (
        .clk           (clk),
        .rst_n         (rst_n),
        // Command interface
        .cmd_valid     (axi_cmd_valid),
        .cmd_wr        (axi_cmd_wr),
        .cmd_addr      (axi_cmd_addr),
        .cmd_wdata     (axi_cmd_wdata),
        .cmd_ready     (axi_cmd_ready),
        .rsp_valid     (axi_rsp_valid),
        .rsp_rdata     (axi_rsp_rdata),
        // AXI master ports
        .M_AXI_AWADDR  (m_axi_awaddr),
        .M_AXI_AWVALID (m_axi_awvalid),
        .M_AXI_AWREADY (m_axi_awready),
        .M_AXI_WDATA   (m_axi_wdata),
        .M_AXI_WSTRB   (m_axi_wstrb),
        .M_AXI_WVALID  (m_axi_wvalid),
        .M_AXI_WREADY  (m_axi_wready),
        .M_AXI_BRESP   (m_axi_bresp),
        .M_AXI_BVALID  (m_axi_bvalid),
        .M_AXI_BREADY  (m_axi_bready),
        .M_AXI_ARADDR  (m_axi_araddr),
        .M_AXI_ARVALID (m_axi_arvalid),
        .M_AXI_ARREADY (m_axi_arready),
        .M_AXI_RDATA   (m_axi_rdata),
        .M_AXI_RRESP   (m_axi_rresp),
        .M_AXI_RVALID  (m_axi_rvalid),
        .M_AXI_RREADY  (m_axi_rready)
    );

    // =========================================================================
    // 8.  Memory Controller FSM
    // =========================================================================
    mem_ctrl #(
        .MEM_DEPTH (MEM_DEPTH),
        .UART_BASE (UART_BASE)
    ) u_mem_ctrl (
        .clk           (clk),
        .rst_n         (rst_n),
        // AXI command interface
        .axi_cmd_valid (axi_cmd_valid),
        .axi_cmd_wr    (axi_cmd_wr),
        .axi_cmd_addr  (axi_cmd_addr),
        .axi_cmd_wdata (axi_cmd_wdata),
        .axi_cmd_ready (axi_cmd_ready),
        .axi_rsp_valid (axi_rsp_valid),
        .axi_rsp_rdata (axi_rsp_rdata),
        // BRAM port B
        .mem_en        (mem_en_b),
        .mem_we        (mem_we_b),
        .mem_addr      (mem_addr_b),
        .mem_din       (mem_din_b),
        .mem_dout      (mem_dout_b),
        // RISC control
        .risc_reset    (risc_reset),
        .risc_stop     (risc_stop),
        .risc_start    (risc_start)
    );

    // =========================================================================
    // 9.  Block Memory (true dual-port BRAM)
    // =========================================================================
    block_memory #(
        .MEM_DEPTH (MEM_DEPTH)
    ) u_bram (
        // Port A � RISC core
        .clk_a   (clk),
        .en_a    (mem_en_a),
        .we_a    (mem_we_a),
        .addr_a  (mem_addr_a),
        .din_a   (mem_din_a),
        .dout_a  (mem_dout_a),
        // Port B � MemCtrl
        .clk_b   (clk),
        .en_b    (mem_en_b),
        .we_b    (mem_we_b),
        .addr_b  (mem_addr_b),
        .din_b   (mem_din_b),
        .dout_b  (mem_dout_b)
    );

    // =========================================================================
    // 10. seq_core instantiation
    //
    // seq_core uses a SEPARATE instruction memory port (pc / instruction).
    // For this minisystem the instruction memory can be a second BRAM or a
    // distributed-RAM ROM initialised from a .mem file.  Here we expose the
    // pc/instruction wires at the top level so they can be connected to
    // whatever program-memory resource is used in the block design.
    //
    // Data memory (LOAD/STORE) uses BRAM port A (mem_en_a / mem_we_a / ...).
    // =========================================================================

    localparam ADDR_WIDTH = $clog2(MEM_DEPTH);

    // Instruction memory wires (connect to your program ROM in the block design)
    wire [ADDR_WIDTH-1:0] risc_pc;
    wire [15:0]           risc_instruction;   // driven by program ROM

    assign imem_addr        = risc_pc;
    assign risc_instruction = imem_data;

    seq_core #(
        .ADDR_WIDTH (ADDR_WIDTH),
        .DATA_WIDTH (32)
    ) u_seq_core (
        .clk         (clk),
        .rst         (risc_reset),      // active-high sync reset from MemCtrl
        .stop        (risc_stop),       // active-high freeze    from MemCtrl
        .start       (risc_start),      // active-high run-enable from MemCtrl
        // Instruction memory
        .pc          (risc_pc),
        .instruction (risc_instruction),
        // Data memory � BRAM port A
        .mem_en      (mem_en_a),
        .mem_we      (mem_we_a),
        .mem_addr    (mem_addr_a),
        .mem_din     (mem_din_a),
        .mem_dout    (mem_dout_a)
    );

endmodule